logitreg.list <- function(design, response, ...){
  
  design_matrix <- do.call(cbind, design)
  # checks for same vector lengths
  
  if(!all(design_matrix[, 1] == 1)){
   stop("intercept of <design> can only be an one vector") 
  }
  
  logitreg.default(design = design_matrix,
                   response = response, ...)
}


#-------


  
