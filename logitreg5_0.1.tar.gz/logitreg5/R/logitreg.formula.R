logitreg.formula <- function(design, data = NULL, ...){
  
  # input checking
  if(grepl("- 1", toString(eval(quote(design))))){
    stop("<design> cannot contain '- 1'. Model fitting without 
         intercept is not implemented.")
  }
  # end input checking
  
  if(is.null(data)){
    model_frame <- eval(bquote(model.frame(.(design))), parent.frame())
    
    model_frame_length <- length(model_frame)
    
    for (i in seq_len(model_frame_length)){
      if(is.factor(model_frame[,i])){
        levels(model_frame[,i]) <- c(0,1)
        model_frame[,i] <- as.numeric(as.character(model_frame[,i]))
      }
    }
  

  }
  else{
    model_frame <- model.frame(design, data) 
  }
  
  design_matrix <- cbind(intercept=1, as.matrix(model_frame[ ,-1]))
  logitreg.default(design = design_matrix,
             response = model_frame[, 1],
             ...)
}